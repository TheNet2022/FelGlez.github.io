# reactionTest - author jrw@mit.edu

## Test the users reaction time to click on a button

## Based on F1 lights-go-out to start car races

# You must get the IP address that server.js is running on and put it into block.html
